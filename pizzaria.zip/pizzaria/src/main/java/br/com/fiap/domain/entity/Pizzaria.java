package br.com.fiap.domain.entity;

import jakarta.persistence.*;

import javax.annotation.processing.SupportedSourceVersion;

@Entity
public class Pizzaria {
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "SQ_PIZZARIA")
    @SequenceGenerator(name = "SQ_PIZZARIA",sequenceName = "SQ_PIZZARIA")
    private Long id;

    private String name;

    public Pizzaria() {
    }

    public Pizzaria(Long id, String name) {
        this.id = id;
        this.name = name;
    }
}
